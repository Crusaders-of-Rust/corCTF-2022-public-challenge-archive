import startMailServer from './mail.js'
import startWebServer from './web.js'

startMailServer();
startWebServer();